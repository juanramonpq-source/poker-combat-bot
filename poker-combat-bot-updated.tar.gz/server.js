const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

// Serve ONLY poker_combat_bot_ONLINE.html - no other HTML files
app.get('/', (req, res) => {
  console.log('[SERVER] GET / -> Serving poker_combat_bot_ONLINE.html');
  res.sendFile(__dirname + '/poker_combat_bot_ONLINE.html');
});

// Serve static files (assets, audio, images) from assets/ folder
app.use('/assets', express.static(__dirname + '/assets'));

// ANY other route also serves the main HTML (SPA behavior)
app.get('*', (req, res) => {
  if (req.path.includes('.')) {
    // If it's a file request (has extension), check assets folder
    const filePath = __dirname + req.path;
    res.sendFile(filePath, (err) => {
      if (err) res.status(404).send('Not found');
    });
  } else {
    // Otherwise serve poker_combat_bot_ONLINE.html
    console.log('[SERVER] GET', req.path, '-> Serving poker_combat_bot_ONLINE.html');
    res.sendFile(__dirname + '/poker_combat_bot_ONLINE.html');
  }
});

// Room storage
const rooms = new Map(); // code → { host, guest, hostNick, guestNick }

function generateCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do {
    code = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  } while (rooms.has(code));
  return code;
}

io.on('connection', (socket) => {
  console.log('Connected:', socket.id);

  socket.on('create_room', ({ nickname }) => {
    if (!nickname || !nickname.trim()) return socket.emit('room_error', 'Introduce tu nombre primero.');
    const code = generateCode();
    rooms.set(code, { host: socket.id, guest: null, hostNick: nickname.trim(), guestNick: null });
    socket.roomCode = code;
    socket.role = 'host';
    socket.join(code);
    socket.emit('room_created', { code });
    console.log(`Room ${code} created by ${nickname}`);
  });

  socket.on('join_room', ({ code, nickname }) => {
    if (!nickname || !nickname.trim()) return socket.emit('room_error', 'Introduce tu nombre primero.');
    const upperCode = (code || '').toUpperCase().trim();
    const room = rooms.get(upperCode);
    if (!room) return socket.emit('room_error', 'Sala no encontrada. Verifica el código.');
    if (room.guest) return socket.emit('room_error', 'Sala completa. Inténtalo con otro código.');
    room.guest = socket.id;
    room.guestNick = nickname.trim();
    socket.roomCode = upperCode;
    socket.role = 'guest';
    socket.join(upperCode);
    socket.emit('room_joined', { code: upperCode, opponentNick: room.hostNick });
    io.to(room.host).emit('guest_joined', { opponentNick: room.guestNick });
    console.log(`Room ${upperCode}: ${room.hostNick} vs ${room.guestNick}`);
  });

  socket.on('state_update', (data) => {
    if (socket.role !== 'host' || !socket.roomCode) return;
    socket.to(socket.roomCode).emit('state_update', data);
  });

  socket.on('player_action', (action) => {
    console.log('[SERVER] player_action received:', action.type, 'from:', socket.id, 'role:', socket.role);
    if (socket.role !== 'guest' || !socket.roomCode) {
      console.log('[SERVER] player_action rejected: role=' + socket.role + ', roomCode=' + socket.roomCode);
      return;
    }
    const room = rooms.get(socket.roomCode);
    if (!room) {
      console.log('[SERVER] player_action rejected: room not found for code=' + socket.roomCode);
      return;
    }
    console.log('[SERVER] Forwarding player_action to host:', room.host);
    io.to(room.host).emit('player_action', action);
  });

  socket.on('disconnect', () => {
    if (!socket.roomCode) return;
    const room = rooms.get(socket.roomCode);
    if (room) {
      socket.to(socket.roomCode).emit('opponent_disconnected');
      rooms.delete(socket.roomCode);
      console.log(`Room ${socket.roomCode} closed.`);
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Poker Combat server running on port ${PORT}`));
